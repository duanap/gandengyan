# 干瞪眼｜开发准备包

> 规则基线：V1.3 · 技术方案：Go + Vue 3 + WebSocket · 文档包：1.0
>
> 本包为开发前的设计与验收依据，不包含已经实现的游戏源码、运行服务或已通过的测试结果。

## 1. 项目目标

开发一个支持 2～5 人实时联机的网页版干瞪眼小游戏。使用一副 54 张牌，支持经典模式和极速模式；服务端权威判定，前端分别适配 PC 和手机横屏布局。优先保证规则准确、游戏公平、弱网恢复与单人维护的便利性。

## 2. 文档索引

| 文件 | 内容 | 使用时机 |
| --- | --- | --- |
| [AGENTS.md](AGENTS.md) | 开发约束、文档优先级、工程验收约定 | 放到项目根目录，供 Codex 等编码代理读取 |
| [CODEX_TASK.md](CODEX_TASK.md) | 可直接提交的开发任务提示词 | 启动开发 |
| [docs/RULES.md](docs/RULES.md) | V1.3 正式游戏规则及边界 | 规则引擎、状态机、玩家规则说明 |
| [docs/DECISIONS.md](docs/DECISIONS.md) | 已确认规则与工程默认值，待确认的非核心选项 | 防止擅自改变规则 |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | 总体架构、模块、状态模型、并发和恢复 | 工程设计 |
| [docs/PROTOCOL.md](docs/PROTOCOL.md) | HTTP / WebSocket 接口、消息格式、信息隔离 | 联机与前后端协作 |
| [docs/FRONTEND.md](docs/FRONTEND.md) | 页面结构、交互、万能牌选择、移动端适配 | 前端实现与视觉设计 |
| [docs/AI.md](docs/AI.md) | 公平 AI 的独立模块设计 | AI 阶段（可选） |
| [docs/TEST_PLAN.md](docs/TEST_PLAN.md) | 单元测试、集成测试、模拟对局与验收清单 | 测试与发布门禁 |
| [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) | 单进程部署、Nginx、systemd、安全与回滚 | 公网部署 |
| [docs/IMPLEMENTATION_PLAN.md](docs/IMPLEMENTATION_PLAN.md) | 开发顺序、里程碑、交付标准 | 执行任务 |
| [docs/ROADMAP.md](docs/ROADMAP.md) | 未来一人失败、两人失败等拓展 | 后续版本；不进入当前正式玩法 |

## 3. 当前范围

- 2、3、4、5 人房间；54 张牌；首家 6 张，其余 5 张。
- 经典模式：一轮结束后全员各补一张；极速模式：仅最后成功出牌者补一张。
- 普通牌型大一级接牌；单 2 / 对 2 特殊压制；三至六张炸弹跨级比较。
- 大小王等价万能牌，无王炸；双王私密提醒。
- 出牌前检查剩余手牌，禁止遗留单 2、对 2、单王、双王或 2＋王。
- 第一名玩家合法出完即结束，不再接牌或补牌；牌堆耗尽则继续出牌但不补牌。
- 实时联机、服务端状态同步、断线重连、完整规则测试。
- AI 采用独立策略模块，是否纳入首发由任务范围明确；未来多胜者玩法只记录在路线图。

## 4. 技术基线

Go 单体服务；Vue 3 + TypeScript + Vite + Pinia；HTTP / WebSocket JSON；内存房间；可选 Go Embed 打包前端；Nginx + systemd 部署。无数据库、Redis、Docker、微服务或消息中间件的强制依赖。

## 5. 使用方法

1. 解压本包，将根目录的 `AGENTS.md`、`CODEX_TASK.md` 和 `docs/` 放入新建或已有的项目仓库。
2. 先阅读 `docs/RULES.md` 与 `docs/DECISIONS.md`，锁定规则及工程默认值。
3. 将 `CODEX_TASK.md` 的内容提交给 Codex，按照 `docs/IMPLEMENTATION_PLAN.md` 执行。
4. 首先实现规则引擎和模拟测试，再接入联机、页面及部署。
5. 按 `docs/TEST_PLAN.md` 验收；不要把本文档视作已经通过验收的证明。

## 6. 文档优先级

明确的用户规则 > `RULES.md` > `DECISIONS.md` 中的工程默认值 > 架构和协议 > 实现计划。`ROADMAP.md` 仅记录未来方向。若发现冲突，应修正文档或明确记录差异，不得擅自以通用干瞪眼规则替代本项目定制规则。
